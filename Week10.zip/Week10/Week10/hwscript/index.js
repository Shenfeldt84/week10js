console.log("Я учу Java Script!");
