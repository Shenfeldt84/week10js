function calculateTotalPrice(quantity = 2, price = 15000000) {
  let totalPrice = quantity * price;
  console.log(totalPrice);
  console.log(totalPrice.toLocaleString("ru-RU"));

  alert("Стоимость покупки: 1 000 рублей.");
}

calculateTotalPrice(2, 500);
